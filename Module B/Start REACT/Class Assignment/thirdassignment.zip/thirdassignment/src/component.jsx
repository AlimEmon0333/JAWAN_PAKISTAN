import "../node_modules/bootstrap/dist/css/bootstrap.min.css"

//  _______________ Table ______________//

function Table(props) {
    const { name, fName, clasS, age, rollNum } = props
    return (
        <div>
            <table className="table">
                <thead>
                    <tr>
                        <th>
                            S.Name
                        </th>
                        <th>
                            F.Name
                        </th>
                        <th>
                            Class
                        </th>
                        <th>
                            Roll Num
                        </th>
                        <th>
                            Age
                        </th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            {name}
                        </td>
                        <td>
                            {fName}
                        </td>
                        <td>
                            {clasS}
                        </td>
                        <td>
                            {rollNum}
                        </td>
                        <td>
                            {age}
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    )
}

//  _______________ Buttons ______________//

function Button(props) {
    return (
        <span className="text-center">
            <button className="btn btn-dark mx-3 my-3 p-3" onClick={props.onclick}>{props.buttonval}</button>
        </span>
    )
}

//  _______________ Inputs ______________//

function Input(props) {
    return (
        <div>
            <input className="w-25 my-3 rounded bg-info p-2"   type={props.InpType} value={props.InpVal} onChange={props.onchange}/>
        </div>
    )
}

//  _______________ Cards ______________//

function Cards(props) {
    const {img,id,name,age,institute,isactive,category}=props
    return(
        <div className="container text-center my-5">
            <div className="row">
                <div className="col-md-4 my-5">
                   <p>{img}</p>
                   <p>Id: {id}</p>
                   <p>Name: {name}</p>
                   <p>Age:{age}</p>
                   <p>Institute:{institute}</p>
                   <p>Is Active :{isactive ? "Yes" : "No"}</p>
                   <p>Categoty :{category}</p>
                </div>
            </div>
        </div>
    )
}














export { Table, Button , Input , Cards}