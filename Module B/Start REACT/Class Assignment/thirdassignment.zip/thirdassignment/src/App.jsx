import "../node_modules/bootstrap/dist/css/bootstrap.min.css"
import './App.css';
import { Table, Button, Input , Cards} from "./component";
import img_1 from "./images/card-1.jpg"
import img_2 from "./images/card-2.jpg"
import img_3 from "./images/card-3.jpg"
import img_4 from "./images/card-4.jpg"
import img_5 from "./images/card-5.jpg"

function App() {
  let arr = [
    {
      name: "M.Ali",
      f_name: "M.Amin",
      class: "10",
      RollNum: "2783",
      age: "16",
    },
    {
      name: "Adil",
      f_name: "Haroon",
      class: "9",
      RollNum: "27793",
      age: "17",
    },
    {
      name: "A.Ahad",
      f_name: "M.Amin",
      class: "9",
      RollNum: "32121",
      age: "8",
    },
    {
      name: "A.Basit",
      f_name: "M.Amin",
      class: "7",
      RollNum: "1790",
      age: "13",
    },
    {
      name: "M.Talha",
      f_name: "M.Amin",
      class: "3",
      RollNum: "001",
      age: "7",
    },
  ]
  let user = [
    { 
      img: <img src={img_1} alt="" />,
      id:1,
      name: "M.Ali",
      age: "16",
      institute : "SAI",
      isactive : true,
      category : "Abc",
      
    },
    {
      img : <img src={img_2} alt="" />,
      id:2,
      name: "Adil",
      age: "17",
      institute : "SAI",
      isactive : true,
      category : "DEF",

    },
    {
      img : <img src={img_3} alt="" />,
      id:3,
      name: "A.Ahad",
      age: "28",
      institute : "NCR",
      isactive : false,
      category : "GHI",
    },
    {
      img : <img src={img_4} alt="" />,
      id:4,
      name: "A.Basit",
      age: "15",
      institute : "Tabanis",
      isactive : false,
      category : "JKL",
    },
    {
      img : <img src={img_5} alt="" />,
      id:5,
      name: "M.Talha",
      age: "23",
      institute : "NCR",
      isactive : true,
      category : "MNO",
    },
  ]
  return (
    <div className="App text-center">

      {/* Table */}

      {arr.map((x) => {

        return (
          <Table name={x.name} fName={x.f_name} clasS={x.class} age={x.age} rollNum={x.RollNum} />
        )
      })}

      {/* Button */}

      <Button buttonval="Ali" onclick={() => { alert('Ali') }} />
      <Button buttonval="Ahad" onclick={() => { alert('Ahad') }} />
      <Button buttonval="Basit" onclick={() => { alert('Basit') }} />
      <Button buttonval="Hassan" onclick={() => { alert('Hassan') }} />
      <Button buttonval="Talha" onclick={() => { alert('Talha') }} />

      {/* Inputs */}

      <Input InpVal="Enter" InpType="text" onchange={() => { alert("Enter text in this input because its type is text") }} />
      <Input InpVal="123" InpType="number" onchange={() => { alert("Enter Number in this input because its type is Number") }} />
      <Input InpVal="Hy" InpType="password" onchange={() => { alert("Enter Password in this input because its type is Password") }} />
      <Input InpVal="Hello" InpType="date" onchange={() => { alert("Enter Date in this input because its type is Date") }} />
      <Input InpVal="Hello Buddy" InpType="month" onchange={() => { alert("Enter Month in this input because its type is Month") }} />

      {/* Cards */}
      
      {user.map((x)=>{
        return(
          <span>
            <Cards img={x.img} id={x.id} name={x.name} age={x.age} institute={x.institute} isactive={x.isactive} category={x.category}/>            
          </span>
        )
      })}

    </div>
  );
}

export default App;
